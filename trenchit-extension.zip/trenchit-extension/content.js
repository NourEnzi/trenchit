const trenchCommands = {
    "/trench.code": "For this project task, please output the complete, production-ready code from start to finish without any placeholders or shortened comments.",

    "/trench.raw": "Please provide the direct technical solution immediately without any conversational filler, introductory remarks, or polite summaries.",

    "/trench.arch": "Analyze this technical problem as a Senior Systems Engineer, focusing on edge cases, data structures, and comparative markdown tables.",

    "/trench.biz": "Provide the response strictly as structured bullet points containing actionable items and clear key performance indicators.",

    "/trench.blog": `Act as a Senior Technical Editor and IT Strategist. The target audience consists of IT Administrators, DevOps Engineers, Developers, and Enterprise Tech Decision-Makers.

Please deeply analyze and evaluate the following article draft based on these 4 criteria:
1. Technical Depth & Accuracy: Is the information accurate, up-to-date (keeping in mind the 2026 tech landscape), and free of superficial fluff?
2. Tone and Voice: Does it sound authoritative, strategic, and highly professional? (It must not sound like a generic, fluffy AI output).
3. Structure and Flow: Are the logical transitions smooth? Are the sub-headings used effectively to guide the reader?
4. Actionability: Does the reader walk away with a clear strategic mindset or a tangible technical understanding?

Please provide your brutal, honest feedback in the following exact format:
- Overall Score (out of 10)
- 3 Core Strengths of the article.
- 3 Areas for Improvement (Be harsh, specific, and point out any weak sentences).
- Suggested Edits: Rewrite 1 or 2 paragraphs that are currently weak to make them punchier, more engaging, and better suited for a senior IT audience.

Here is the article draft:`
};

document.addEventListener('keyup', function(e) {
    if (e.code === 'Space') {
        let target = e.target;
        if (target.tagName.toLowerCase() === 'textarea' || target.isContentEditable) {
            let text = target.tagName.toLowerCase() === 'textarea' ? target.value : target.innerText;
            
            for (let cmd in trenchCommands) {
                if (text.includes(cmd)) {
                    let newText = text.replace(cmd, trenchCommands[cmd]);
                    
                    if (target.tagName.toLowerCase() === 'textarea') {
                        target.value = newText;
                    } else {
                        target.innerText = newText;
                    }
                    target.dispatchEvent(new Event('input', { bubbles: true }));
                }
            }
        }
    }
}, true);